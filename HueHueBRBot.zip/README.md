# HueHueBR Bot (Telegram)

Bot oficial do token HBR.
Funções:

- Preço do HBR
- Alertas de compra
- Mint NFT
- Alertas de mint
- Info do token
- Info dos NFTs

## Deploy (Railway)

1. Crie um novo projeto
2. Envie o ZIP com todos os arquivos
3. Vá em Variables e copie o .env.example
4. Railway inicia automaticamente

## Comandos

/start
/price
/tokeninfo
/nftinfo
/buy
/mint
/help
